import MovieFlashcardGame from '../components/MovieFlashcardGame'

export default function Home() {
  return (
    <main>
      <MovieFlashcardGame />
    </main>
  )
}

